<a HREF="source.txt">show source</A><br /><br />

<?php

// REAR's libs
require_once "SOAP/Client.php";

class SOAPGoogleAPI {

/** 
   key - Google API key
   q - search word or phrase
   start - the index of the result to start on
   maxResults - the number of results to return
   filter - if True, Google will filter out duplicate pages from the results
   restrict - set this to country plus a country code to get results only from a particular country
   safeSearch - if True, Google will filter out porn sites
   lr - set this to a language code to get results only in a particular language
   ie and oe - deprecated, both must be utf-8.
*/
	  
  var $soap_google_url_search = "http://api.google.com/search/beta2";
  var $dev_key = "";
  var $soap = NULL;
  var $q;
  var $start;
  var $maxResults;
  var $filter;
  var $restrict;
  var $safeSearch;
  var $lr;   
  var $ie;   
  var $oe;                
	
  
  // Construct
  function SOAPGoogleAPI( $key, $array_params ) {	         
    $this->dev_key = $key;        
    $this->soap = new SOAP_Client($this->soap_google_url_search);
    $this->q = isset($array_params["query"]) ? $array_params["query"] : "ruby";
    $this->start = isset($array_params["start"]) ? $array_params["start"] : 0;
    $this->maxResults = isset($array_params["maxResults"]) ? $array_params["maxResults"] : 10;
    $this->filter = isset($array_params["filter"]) ? $array_params["filter"] : false;
    $this->restrict = isset($array_params["restrict"]) ? $array_params["restrict"] : "";
    $this->safeSearch = isset($array_params["safeSearch"]) ? $array_params["safeSearch"] : false;
    $this->lr = isset($array_params["lr"]) ? $array_params["lr"] : ""; 
    $this->ie = isset($array_params["ie"]) ? $array_params["ie"] : "utf-8";
    $this->oe = isset($array_params["oe"]) ? $array_params["oe"] : "utf-8";
	
  }

  function search() {
    return $this->SOAPCall( "doGoogleSearch",
								  array(
								  		"key" => $this->dev_key,
										"q" => $this->q,
										"start" => $this->start,
										"maxResults"  => $this->maxResults,
										"filter" => $this->filter,
										"restrict" => $this->restrict,
										"safeSearch" => $this->safeSearch,
										"lr"  => $this->lr,
										"ie" => $this->ie,
										"oe"  => $this->oe
									)
								);
  }    
	  
  function SOAPCall( $set_api_function, $params ){
    $result = $this->soap->call( $set_api_function, $params, "urn:GoogleSearch" );
    if( !PEAR::isError( $result ) ) {
      return $result;        
    } 
    else {
      return false;        
    }    
  }
}

if( isset( $_POST['string'] ) ) {
  if( !empty( $_POST['string'] ) ) {
  
  	echo "<FORM ACTION=\"index.php\" METHOD=\"POST\">";
	echo "<INPUT TYPE=\"TEXT\" NAME=\"string\" SIZE=\"20\">";
	echo "<INPUT TYPE=\"SUBMIT\" NAME=\"ok\">";
    echo "</FORM>";
	
    $dev_key = "OS7mOjxQFHIztxIYU9yb8y3ibYgY4w2o";
    $array_params = array();
    $array_params = array('query' => $_POST['string'] );
	
	$google = new SOAPGoogleAPI($dev_key, $array_params);
	
	$result = $google->search();
	echo 'Szukano dla: ' . $_POST['string'] . '<br /><br />';
	if( $result ) {
	  foreach( $result->resultElements as $value ) {
	    echo "<a href=\"" . $value->URL . "\">" . $value->title . "</a><br />";
		echo $value->snippet . "<br /><br /><hr><br />";
	  }
    }
    else {
      unset( $_POST['string'] );
      die('Nie znaleziono wynikow lub Google API nie odpowiada. Sprobuj jeszcze raz<br /><br />');
    }
  unset( $_POST['string'] );
  }
  else {
    unset( $_POST['string'] );
    echo 'Wypelnij poprawnie!<br /><br />';
	echo "<FORM ACTION=\"index.php\" METHOD=\"POST\">";
	echo "<INPUT TYPE=\"TEXT\" NAME=\"string\" SIZE=\"20\">";
	echo "<INPUT TYPE=\"SUBMIT\" NAME=\"ok\" value=\" szukaj... \">";
    echo "</FORM>";
  }
}
else {
  echo "<FORM ACTION=\"index.php\" METHOD=\"POST\">";
  echo "<INPUT TYPE=\"TEXT\" NAME=\"string\" SIZE=\"20\">";
  echo "<INPUT TYPE=\"SUBMIT\" NAME=\"ok\">";
  echo "</FORM>";
}


?>