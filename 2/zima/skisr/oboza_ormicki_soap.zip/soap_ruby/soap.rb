# -----------------------------------------------------------------------------------
# doGoogleSearch(key, q, start, maxResult, filter,  restrict, safeSearch, lr, ie, oe)
#
# key - Google API key
# q - search word or phrase
# start - the index of the result to start on
# maxResults - the number of results to return
# filter - if True, Google will filter out duplicate pages from the results
# restrict - set this to country plus a country code to get results only 
#            from a particular country
# safeSearch - if True, Google will filter out porn sites
# lr - set this to a language code to get results only in a particular language
# ie and oe - deprecated, both must be utf-8.
# 
# ------------------------------------------------------------------------------------

# include ruby's libs
require 'soap/wsdlDriver'
require 'cgi'


class Get_result
  @@wsdl = "http://api.google.com/GoogleSearch.wsdl"
  def initialize(query) #construct
    @q = query
  end
  def read_dev_key(*args) #get the developer key from file
    f = res = File.read(*args).chomp
    if block_given?
      res = yield f
      f.close
    end
    return res
  end
  def soap_inst #return SOAP driver using WSDL
    return SOAP::WSDLDriverFactory.new(@@wsdl).create_rpc_driver        
  end  
  def conn #connect to Google API and return result(s) if true
    @d = read_dev_key("developer_key.txt")
    return soap_inst.doGoogleSearch(@d, @q, 0, 10, false, "", false, "", "utf-8", "utf-8")
  end
  # set permission to the method
  private :soap_inst
  public :conn
end


printf "\nPut word or phrase: "
query = gets

handle = Get_result.new(query)
result = handle.conn

printf "\nThe number of results %d.\n", result.estimatedTotalResultsCount
printf "Search in %6f sec.\n", result.searchTime

if result.resultElements.size != 0
	printf "\nResult(s):\n\n"
	count = 0
	result.resultElements.each do
		|var|
		count += 1
		printf "No:\t\t%d\n", count
		puts "Title:\t\t" + var['title']
		puts "Home Url:\t" + var['URL']
		puts "Description:\t" + CGI.unescapeHTML(var['snippet'])
		2.times {puts}
	end
else
	puts "\nNo result."
end
