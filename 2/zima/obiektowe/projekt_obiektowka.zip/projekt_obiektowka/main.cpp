/*
	Program Store.
	Pliki projektu:
		- Class.crypt.h
		- Class.cmd.h
		- Class.store.h
		- Class.fileInterface.h
		- Struct.product.h
		- main.cpp
		
		(c) Darek Ormicki, gr 3, sem III, IS WIMiIP, OOP Project
*/

#include <iostream>
#include <string>
#include <fstream>
#include <windows.h>
#include <stdio.h>

using namespace std;

// Ilosc przesuniec bitowych dla metod encrypt() i decrypt().
#define  ENC			(int) one_byte + 1
#define  DEC			(int) one_byte - 1

// Nazwy plikow wynikowych dla aplikacji.
#define  DB				"data.txt"
#define  DB_B 		"data_backup.txt"
#define  DB_ENC		"data_enc.txt"
#define  DB_DEC		"data_dec.txt"

// Pliki naglowkowe aplikacji.
#include "Struct.product.h"
#include "Class.crypt.h"
#include "Class.fileInterface.h"
#include "Class.cmd.h"
#include "Class.store.h"

// Utworz egzemplarz klasy Store.
void start();
// Utworz egzemplarz klasy Crypt.
void crypt(bool);

// Program glowny.
int main(int argc, char *argv[]){
  
	string command_str;
	string command_const[] = { "start", "encrypt", "decrypt", "help", "exit" };
	short int command_int;
	bool menu = true;
	unsigned short int i;
	
	// Inicjalizacja linii polecen.	
	CommandLine *cmdP = new CommandLine;
	
  cmdP->cmd_show(1, true);
	std::cout << "\t************************ Witamy *************************\n";
	std::cout << "\t* Aby uruchomic program wpisz w linii polecen  \"start\"\t*\n";
	std::cout << "\t* Szyfrowanie pliku bazy - \"encrypt\"\t\t\t*\n";
	std::cout << "\t* Deszyfrowanie danych - \"decrypt\"\t\t\t*\n";
	std::cout << "\t* Aby uzyskac pomoc  \"help\"\t\t\t\t*\n";
	std::cout << "\t* Wyjscie  \"exit\"\t\t\t\t\t*\n";
	std::cout << "\t* \t\t\t\t\t\t\t*\n";
	std::cout << "\t* Zyczymy milej pracy...\t\t\t\t*\n";
	std::cout << "\t*********************************************************\n\n";

	while(menu){
    command_int = -1;
		cmdP->cmd_show(1, false);
		std::cin >> command_str;
		for(i = 0; i<5; i++){
			if(command_str == command_const[i]){
				command_int = i;
			}
		}
		switch(command_int){
			case 0:
        cmdP->cmd_show(1, true);
        std::cout << "\tUruchamianie programu...\n";
        std::cout << "\tProgram Store zaladowany.\n\n";
				start();
				break;
			case 1:
        cmdP->cmd_show(1, true);
        std::cout << "\tSzukanie pliku bazy danych...\n\n";
        crypt(true);
				break;
			case 2:
        cmdP->cmd_show(1, true);
        std::cout << "\tSzukanie pliku zaszyfrowanej bazy danych...\n\n";
        crypt(false);
				break;
			case 3:
        cmdP->cmd_show(1, true);
				std::cout << "\t************************ Pomoc **************************\n";
				std::cout << "\t* \"start\" - laduje program Store\t\t\t*\n";
				std::cout << "\t* \"encrypt\" - szyfruje plik bazy\t\t\t*\n";
				std::cout << "\t* \"decrypt\" - deszyfruje plik bazy\t\t\t*\n";
				std::cout << "\t* \"help\" - uruchamia pomoc\t\t\t\t*\n";
				std::cout << "\t* \"exit\" - konczy aplikacje\t\t\t\t*\n";
				std::cout << "\t* \t\t\t\t\t\t\t*\n";
				std::cout << "\t* \"data.txt\" - plik bazy danych programu Store\t\t*\n";
				std::cout << "\t*********************************************************\n\n";
				break;
			case 4:
				menu = false;
				break;
			default :
				std::cout << "Polecenie nierozpoznane. Wpisz \"help\" aby uzyskac wiecej informacji.\n";
				break;
		}
	}
  return EXIT_SUCCESS;
}

void start(){

  // Przekaz sterowanie podprogramowi Stroe.
	Store *start = new Store;
	// Porzadki.
	delete start;
}

void crypt(bool action){

  // Przekaz sterowanie do klasy Crypt.
	Crypt * form = new Crypt(action);
	// Porzadki.
	delete form;
}

