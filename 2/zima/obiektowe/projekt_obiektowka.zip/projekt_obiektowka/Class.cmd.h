/*
	Klasa odpowiedzialna za wyswietlanie i kolorowanie wiersza
	polecen aplikacji w zaleznosci od przebiegu czynnosci.
*/

class CommandLine{
	public:
		// Konstruktor.
    CommandLine();
    // Tworz linie polecen.
    void cmd_show(int, bool);
};

CommandLine::CommandLine(){
}

void CommandLine::cmd_show(int x, bool process){

	// Ustaw kolor: red on black.
  SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED);
  if(x){
		if(process){
      std::cout << "comm::Line *\n";
		}
		else{
      std::cout << "comm::Line>";
		}
  }
  else{
    if(process){
      std::cout << "comm::Line::Store *\n";
		}
		else{
      std::cout << "comm::Line::Store>";
		}
	}
	// Ustaw kolor domyslny: white on black.
  SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
}
