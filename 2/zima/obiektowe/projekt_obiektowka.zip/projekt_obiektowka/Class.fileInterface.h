/*
	Klasa odpowiada za prace zwiazane z plikiem.
	Odczyt, zapis, upgrade etc..
*/

class FileInterface{
	protected:
		Product * list_tmp;
		Product * list_del;
		Product * list_edit;		
		Product * list_backup;				
		Product * list_restore;						
		Product * list_sort_name;
		Product * list_sort_price;
		Product * list;
		int record;
		int count;
		// Wyciagnij istniejace rekordy z bazy.
 		void open_and_get(int);
 		// Sprawdz, czy plik bazy istnieje
 		void if_exist();
 		// Zapisz dane do bazy.
		void save(int);
 		// Oblicz rozmiar bazy.
		void size();
		// Zaktualizuj plik po usunieciu wybranego rekordu.
		void update_del();
		// Zaktualizuj plik po edycji rekordu.
		void update_edit();
		// Stworz kopie zapasowa.
		void backup();		
		// Odtworz baze z kopii zapasowej.
		void restore();				
		// Zaktualizuj plik po sortowaniu wynikow.
		void update_sort(bool);
		// Usuwa biale znaki ze stringa.
		string whitespace_remove(string);		
		// Dodaje biale znaki do stringa podczas wyswietlania wynikow.
		string whitespace_add(string);				
	public:
    // Konstruktor.
		FileInterface();
};

FileInterface::FileInterface(){
}

string FileInterface::whitespace_remove(string str_remove_oryginal){
  
  string str_remove;
  unsigned int i = 0;
  
  // Szukaj spacji i zamien na "_".
  for(i; i<str_remove_oryginal.size(); i++){
    if(str_remove_oryginal[i] != ' '){
      str_remove += str_remove_oryginal[i];
    }
    else{
      str_remove += "_";
    }
  }
  return str_remove;
}

string FileInterface::whitespace_add(string str_add_oryginal){
  
  string str_add;
  unsigned int i = 0;
  
  // Szukaj "_" i zamien na spacje.
  for(i; i<str_add_oryginal.size(); i++){
    if(str_add_oryginal[i] != '_'){
      str_add += str_add_oryginal[i];
    }
    else{
      str_add += " ";
    }
  }
  return str_add;
}

void FileInterface::open_and_get(int list_len = 0){

	int n = 0;
	this->size();
  this->count = list_len + this->record;

	list = new Product[this->count];

  ifstream handle_input;
  handle_input.open(DB);

  // Pobierz istniejace rekordy do pamieci podrecznej.
	if(this->record){
		for(n; n<this->record; n++){
      handle_input >> list[n].no;
      handle_input >> list[n].name;
      list[n].name = this->whitespace_add(list[n].name);
      handle_input >> list[n].description;
      list[n].description = this->whitespace_add(list[n].description);      
      handle_input >> list[n].price;
		}
	}
	handle_input.close();
}

void FileInterface::update_del(){

 	unsigned int i = 0;
	ofstream handle_output;
	handle_output.open(DB);
	
  for(i; i<this->record-1; ++i){
    handle_output << list_del[i].no << endl;
    list_del[i].name = this->whitespace_remove(list_del[i].name);
    handle_output << list_del[i].name << endl;
    list_del[i].description = this->whitespace_remove(list_del[i].description);    
    handle_output << list_del[i].description << endl;
    handle_output << list_del[i].price << endl;
    handle_output << "\n\n";
	}
	handle_output.close();
}

void FileInterface::update_edit(){

 	unsigned int i = 0;
	ofstream handle_output;
	handle_output.open(DB);
	
  for(i; i<this->record; ++i){
    handle_output << list_edit[i].no << endl;
    list_edit[i].name = this->whitespace_remove(list_edit[i].name);    
    handle_output << list_edit[i].name << endl;
    list_edit[i].description = this->whitespace_remove(list_edit[i].description);    
    handle_output << list_edit[i].description << endl;
    handle_output << list_edit[i].price << endl;
    handle_output << "\n\n";
	}
	handle_output.close();
}

void FileInterface::backup(){

  // Laduj rekordy do bufora.
	this->open_and_get();
 	unsigned int i = 0;
	ofstream handle_output;
	handle_output.open(DB_B);
	
  for(i; i<this->record; ++i){
    handle_output << list[i].no << endl;
    list[i].name = this->whitespace_remove(list[i].name);
    handle_output << list[i].name << endl;
    list[i].description = this->whitespace_remove(list[i].description);
    handle_output << list[i].description << endl;
    handle_output << list[i].price << endl;
    handle_output << "\n\n";
	}
	handle_output.close();
}

void FileInterface::restore(){

	// Sprawdz czy plik kopii bazy istnieje.
  ifstream handle_input;
  handle_input.open(DB_B);
  
  
  if(!handle_input){
    std::cout << "\tPlik kopii bazy nie zostal odnaleziony w katalogu macierzystym.\n\n";
  }  
  else{
    
    int s_tmp = 0;
    unsigned int i = 0, n = 0;
    Product * tmp = new Product;
    
    // Zlicz ilosc rekordow znajdujacych sie w bazie.
    while(!handle_input.eof()){
      handle_input >> tmp->no;
      handle_input >> tmp->name;
      handle_input >> tmp->description;
      handle_input >> tmp->price;
      s_tmp++;
    }
    
    handle_input.close();
    
    // Porzadki.
    delete tmp;
    s_tmp -= 1;
    
    list_restore = new Product[s_tmp];
    
    ifstream handle_input;
    handle_input.open(DB_B);
    
    // Pobierz istniejace rekordy do pamieci podrecznej.
    if(s_tmp){
      for(n; n<s_tmp; n++){
        handle_input >> list_restore[n].no;
        handle_input >> list_restore[n].name;
        handle_input >> list_restore[n].description;
        handle_input >> list_restore[n].price;
      }
    }
    
    handle_input.close();
    
    this->if_exist();
      
    ofstream handle_output;
    handle_output.open(DB);
        
    if(s_tmp){
      for(i; i<s_tmp; ++i){
        handle_output << list_restore[i].no << endl;
        handle_output << list_restore[i].name << endl;
        handle_output << list_restore[i].description << endl;
        handle_output << list_restore[i].price << endl;
        handle_output << "\n\n";     
      }
    }
    handle_output.close();
    std::cout << "\tPlik bazy zostal pomyslnie odtworzony.\n\n";
  }
}

void FileInterface::update_sort(bool method){

 	unsigned int i = 0;
	ofstream handle_output;
	handle_output.open(DB);
	
	if(method){
    for(i; i<this->record; ++i){
      handle_output << list_sort_price[i].no << endl;
      list_sort_price[i].name = this->whitespace_remove(list_sort_price[i].name);
      handle_output << list_sort_price[i].name << endl;
      list_sort_price[i].description = this->whitespace_remove(list_sort_price[i].description);      
      handle_output << list_sort_price[i].description << endl;
      handle_output << list_sort_price[i].price << endl;
      handle_output << "\n\n";
		}
	}
	else{
		i = 0;
    for(i; i<this->record; ++i){
      handle_output << list_sort_name[i].no << endl;
      list_sort_price[i].name = this->whitespace_remove(list_sort_price[i].name);      
      handle_output << list_sort_name[i].name << endl;
      list_sort_price[i].description = this->whitespace_remove(list_sort_price[i].description);            
      handle_output << list_sort_name[i].description << endl;
      handle_output << list_sort_name[i].price << endl;
      handle_output << "\n\n";
		}
	}
	handle_output.close();
}


void FileInterface::save(int list_len){

  // Laduj rekordy do bufora.
	this->open_and_get(list_len);
	unsigned int n = this->record;
	unsigned int i = 0;

	ofstream handle_output;
	handle_output.open(DB);

	// Zapisz istniejace rekordy z pamieci podrecznej.
	if(this->record){
    for(i; i<this->record; ++i){
      handle_output << list[i].no << endl;
      list[i].name = this->whitespace_remove(list[i].name);      
      handle_output << list[i].name << endl;
      list[i].description = this->whitespace_remove(list[i].description);            
      handle_output << list[i].description << endl;
      handle_output << list[i].price << endl;
      handle_output << "\n\n";
		}
	}

	// Zapisz nowe rekordy w bazie.
	for(n; n<this->count; ++n){
    list[n].no = n+1;
		handle_output << list[n].no << endl;
		
		cin.clear();
		cin.ignore(10000,'\n');

		std::cout << "\tPodaj nazwe produktu: ";
		getline(std::cin, list[n].name);
		handle_output << this->whitespace_remove(list[n].name) << endl;
		
		cin.ignore(0,'\n');		

		std::cout << "\tPodaj opis produktu: ";
		getline(std::cin, list[n].description);		
		handle_output << this->whitespace_remove(list[n].description) << endl;

		std::cout << "\tPodaj cene produktu: ";
		std::cin >> list[n].price;
		handle_output << list[n].price << endl;

		handle_output << "\n\n";
		cout << "\n";
	}
	handle_output.close();
}

void FileInterface::if_exist(){

	// Sprawdz czy plik bazy istnieje, jezeli nie - utworz go.
  ifstream handle_input_tmp;
  handle_input_tmp.open(DB);
  
  if(!handle_input_tmp){
    std::cout << "\tPlik bazy nie zostal odnaleziony w katalogu macierzystym.\n\tTworzenie nowego pliku bazy...\n\n";
    ofstream handle_output;
    handle_output.open(DB);
    if(handle_output){
      handle_output.close();
      std::cout << "\tOperacaja zakonczona sukcesem!\n\n";
    }
    else{
      std::cout << "\tOperacaja utworzenia pliku bazy nie powodla sie! Sprawdz uprawnienia uzytkownika.\n\n";
      exit(1);
    }
  }
}

void FileInterface::size(){

  int s_tmp = 0;
	Product * tmp = new Product;
	
	// Sprawdz, czy plik bazy istnieje
	this->if_exist();

  ifstream handle_input;
  handle_input.open(DB);

  // Zlicz ilosc rekordow znajdujacych sie w bazie.
	while(!handle_input.eof()){
    handle_input >> tmp->no;
    handle_input >> tmp->name;
    handle_input >> tmp->description;
    handle_input >> tmp->price;
		s_tmp++;
	}

	handle_input.close();
	delete tmp;
	this->record = s_tmp-1;
}
