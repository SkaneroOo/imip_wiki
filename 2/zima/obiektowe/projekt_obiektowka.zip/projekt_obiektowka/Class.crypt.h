/*
	Klasa odpowiedzialna za szyfrowanie i deszyfrowanie pliku bazy danych.
	Szyfrogram: Pzesuniecia bitowe.
*/

class Crypt{
  private:
		// Szyfruj plik.
		void encrypt();
		// Dekoduj dane.
		void decrypt();
  public:
    // Konstruktor.
		Crypt(bool);
};

Crypt::Crypt(bool action){

	if(action){
		this->encrypt();
	}
	else{
		this->decrypt();
	}
}

void Crypt::encrypt(){

	char one_byte;

  ifstream handle_input;
  handle_input.open(DB);

  if(!handle_input){
    std::cout << "\tPlik nie zostal odnaleziony w katalogu macierzystym.\n";
    std::cout << "\tWejdz do programu Store, aby go utworzyc.\n\n";
  }
  else{
		handle_input.close();
		
		std::cout << "\tSzyfrowanie...\n\n";
		
		ofstream handle_output;
		
		// Otworz w trybie binarnym.
    handle_input.open(DB, ios::in | ios::binary);
    handle_output.open(DB_ENC, ios::out | ios::binary);

    while(!handle_input.eof()){
			char new_one_byte;
			one_byte = handle_input.get();
			new_one_byte = ENC;
			handle_output.put(new_one_byte);
  	}
  	handle_input.close();
  	handle_output.close();
    std::cout << "\tSzyfrowanie zakonczone. Wynik w pliku: " << DB_ENC << ".\n\n";
    
    ifstream handle_input_cout;
    
    std::cout << "\tPodglad pliku:\n\n";

    handle_input_cout.open(DB_ENC, ios::in | ios::binary);
    
		unsigned int tab = 0;
		
		std::cout << "\t";
    while(!handle_input_cout.eof()){
			std::cout << handle_input_cout.get();
			tab++;
			if(tab >= 23){
				std::cout << "\n\t";
				tab = 0;
			}
  	}
  	handle_input_cout.close();
  	std::cout << "\n\n";
  }
}

void Crypt::decrypt(){

	char one_byte;

  ifstream handle_input;
  handle_input.open(DB_ENC);

  if(!handle_input){
    std::cout << "\tPlik nie zostal odnaleziony w katalogu macierzystym.\n";
    std::cout << "\tNajpierw zaszyfruj plik bazy danych.\n\n";
  }
  else{
		handle_input.close();
		
		std::cout << "\tDeszyfrowanie...\n\n";
		
		ofstream handle_output;
		
    handle_input.open(DB_ENC, ios::in | ios::binary);
    handle_output.open(DB_DEC, ios::out | ios::binary);

    while(!handle_input.eof()){
			char new_one_byte;
			one_byte = handle_input.get();
			new_one_byte = DEC;
			handle_output.put(new_one_byte);
  	}
  	handle_input.close();
  	handle_output.close();
    std::cout << "\tDeszyfrowanie zakonczone. Wynik w pliku: " << DB_DEC << ".\n\n";
  }
}
