/*
	Klasa glowna aplikacji. Wywoluje metody (swoje i przodkow)
	odpowiadajace za sterowanie programem.
*/

class Store : protected FileInterface{
	// Tworz nawigacje podprogramu Store.
	void menu();
	// Wyswietla liste produktow.
	void product_list();
	// Usuwa produkt z bazy o podanym id.
	void product_delete(int);
	// Edytuje produkt o podanym id.
	void product_edit(int);	
	// Szuka produktow po cenie.
	void product_search_price(double, double);
	// Szuka po nazwie / fragmencie nazwy.
	void product_search_name(string);	
	// Sortuj produkty po cenie i nazwie.
	void product_sort(bool);
  public:
    // Konstruktor.
    Store();
};

Store::Store(){

	this->menu();
}

void Store::menu(){

 	string command_str;
	string command_const[] = { "add", "list", "delete", "edit", "search_price", "search_name", "sort_price", "sort_name", "backup", "restore", "commands", "quit" };
	string name;
	short int command_int;
	bool menu = true;
	unsigned short int i, prod_count, prod_id;
	double price_a, price_b;
	
	// Inicjalizacja linii polecen.
	CommandLine *cmdS = new CommandLine;

  cmdS->cmd_show(0, true);
	std::cout << "\t************************ Store **************************\n";
	std::cout << "\t* Aby uzyskac liste komend programu wpisz \"commands\"\t*\n";
	std::cout << "\t* Wyjscie  \"quit\"\t\t\t\t\t*\n";
	std::cout << "\t* \t\t\t\t\t\t\t*\n";
	std::cout << "\t* Zyczymy przyjemnej pracy...\t\t\t\t*\n";
	std::cout << "\t*********************************************************\n\n";

	while(menu){
    command_int = -1;
		cmdS->cmd_show(0, false);
		std::cin >> command_str;
		for(i = 0; i<12; i++){
			if(command_str == command_const[i]){
				command_int = i;
			}
		}
		switch(command_int){
			case 0:
        cmdS->cmd_show(0, true);
        std::cout << "\tIle produktow chcesz dodac? : ";
        std::cin >> prod_count;
        std::cout << "\n";
        this->save(prod_count);
        std::cout << "\tZapis...\n";
        std::cout << "\tPomyslnie dodano do bazy produktow: " << prod_count << "\n\n";
				break;
			case 1:
        cmdS->cmd_show(0, true);
        this->product_list();
				break;
			case 2:
        cmdS->cmd_show(0, true);
        std::cout << "\tPodaj id produktu do usuniecia : ";
        std::cin >> prod_id;
        std::cout << "\n";
        this->product_delete(prod_id);
				break;
			case 3:
        cmdS->cmd_show(0, true);
        std::cout << "\tPodaj id produktu do edycji : ";
        std::cin >> prod_id;
        std::cout << "\n";
        this->product_edit(prod_id);
				break;				
			case 4:
        cmdS->cmd_show(0, true);
        std::cout << "\tSzukaj w przedziale cenowym...\n";
        std::cout << "\t\t Od [pln] : ";
        std::cin >> price_a;
        std::cout << "\t\t Do [pln] : ";
        std::cin >> price_b;
        std::cout << "\n";
        this->product_search_price(price_a, price_b);
				break;
			case 5:
        cmdS->cmd_show(0, true);
        std::cout << "\tSzukaj po nazwie / fragmencie nazwy...\n";
        std::cout << "\t\t Fraza : ";
        std::cin >> name;
        std::cout << "\n";
        this->product_search_name(name);
				break;				
			case 6:
        cmdS->cmd_show(0, true);
        std::cout << "\tSortowanie bazy...\n";
        std::cout << "\n";
        this->product_sort(true);
				break;
			case 7:
        cmdS->cmd_show(0, true);
        std::cout << "\tSortowanie bazy...\n";
        std::cout << "\n";
        this->product_sort(false);
				break;
			case 8:
        cmdS->cmd_show(0, true);
        std::cout << "\tTworzenie kopii zapasowej bazy...\n";
        std::cout << "\n";
        this->backup();
        std::cout << "\tKopia bazy wykonana poprawnie.\n\n";        
				break;		
			case 9:
        cmdS->cmd_show(0, true);
        std::cout << "\tOdtwarzanie bazy danych...\n";
        std::cout << "\n";
        this->restore();
				break;		        		
			case 10:
        cmdS->cmd_show(0, true);
        std::cout << "\n";
				std::cout << "\t \"add\" \t\t\t- dodaje nowy produkt do bazy\n";
				std::cout << "\t \"list\" \t\t- wyswietla rekordy bazy\n";
				std::cout << "\t \"delete\" \t\t- usuwa produkt o danym id\n";
				std::cout << "\t \"edit\" \t\t- aktualizuje produkt o danym id\n";				
				std::cout << "\t \"search_price\" \t- szuka produktu w granichach cenowych\n";
				std::cout << "\t \"search_name\" \t\t- szuka produktu po nazwie / fragmencie\n";
				std::cout << "\t \"sort_price\" \t\t- sortuj baze (klucz: cena)\n";
				std::cout << "\t \"sort_name\" \t\t- sortuj baze (klucz: nazwa)\n";
				std::cout << "\n";
				std::cout << "\t \"backup\" \t\t- tworzy kopie zapasowa bazy danych\n";				
				std::cout << "\t \"restore\" \t\t- odtwarza plik bazy danych z kopii zapasowej\n";								
				std::cout << "\t \"commands\" \t\t- wyswietla liste komend programu\n";
				std::cout << "\t \"quit\" \t\t- konczy aplikacje\n";
				std::cout << "\n\n";
				break;
			case 11:
				menu = false;
				cmdS->cmd_show(0, true);
				std::cout << "\tZamykanie ...\n";
				std::cout << "\tProgram Store zakonczyl dzialanie.\n\n";
				break;
			default :
				std::cout << "Polecenie nierozpoznane. Wpisz \"commands\" aby uzyskac wiecej informacji.\n";
				break;
		}
	}
}

void Store::product_list(){

  // Laduj rekordy do bufora.
	this->open_and_get();
	int i = 0;
	
	if(this->record){
		std::cout << "\tWszystkich wpisow w bazie: " << this->record << "\n\n";
		for(i; i<this->record; i++){
			std::cout << "\t" << list[i].no << ")\tNazwa: \t" << list[i].name;
			std::cout << "\n\t\tCena: \t" << list[i].price << " pln\n";
			std::cout << "\t\tOpis: \t" << list[i].description << "\n\n";
		}
	}
	else{
		std::cout << "\tBaza nie zawiera rekordow.\n\n";
	}
}

void Store::product_delete(int id){
  
  // Laduj rekordy do bufora.
	this->open_and_get();
	unsigned int i = 0;
	bool found = false;

	if(id > 0 && id <=this->record){
		list_del = new Product[this->record];
    for(i; i<this->record; i++){
			if(list[i].no == id){
				if(id == this->record){
				}
				else{
          found = true;
          i++;
				}
			}
			if(found){
        list_del[i-1].no = (int)list[i].no-1;
        list_del[i-1].name = list[i].name;
        list_del[i-1].description = list[i].description;
        list_del[i-1].price = list[i].price;
			}
			else{
        list_del[i].no = list[i].no;
        list_del[i].name = list[i].name;
        list_del[i].description = list[i].description;
        list_del[i].price = list[i].price;
			}
		}
		this->update_del();
		std::cout << "\tProdukt o numerze id: "<< id <<" zostal pomyslnie usuniety.\n\n";
	}
	else{
		std::cout << "\tProdukt o takim numerze id nie istnieje w bazie.\n\n";
	}
}

void Store::product_edit(int id){

  // Laduj rekordy do bufora.
	this->open_and_get();
	unsigned int i = 0, n = 0;
	bool found = false;

	if(id > 0 && id <= this->record){
		list_edit = new Product[this->record];
		
		for(n; n<this->record; n++){
      list_edit[n].no = list[n].no;
      list_edit[n].name = list[n].name;
      list_edit[n].description = list[n].description;
      list_edit[n].price = list[n].price;                  
    }
    for(i; i<this->record; i++){
			if(list_edit[i].no == id){
        
     		cin.clear();
     		cin.ignore(10000,'\n');
		
        std::cout << "\tPodaj nowa nazwe produktu: ";
        getline(std::cin, list_edit[i].name);
        list_edit[i].name = this->whitespace_remove(list_edit[i].name);
        
     		cin.ignore(0,'\n');	
        
        std::cout << "\tPodaj nowy opis produktu: ";
        getline(std::cin, list_edit[i].description);
        list_edit[i].description = this->whitespace_remove(list_edit[i].description);
        
        std::cout << "\tPodaj nowa cene produktu: ";
        std::cin >> list_edit[i].price;
			}
		}
		this->update_edit();
		std::cout << "\n\tProdukt o numerze id: "<< id <<" zostal pomyslnie zaktualizowany.\n\n";
	}
	else{
		std::cout << "\tProdukt o takim numerze id nie istnieje w bazie.\n\n";
	}
}

void Store::product_search_price(double price_a, double price_b){
  
  // Laduj rekordy do bufora.
	this->open_and_get();
	unsigned int found = 0, i = 0;
	
	if(this->record){
		for(i; i<this->record; i++){
			if((double)list[i].price >= price_a && (double)list[i].price <= price_b){
				found++;
			}
		}
		if(found){
			i = 0;
			std::cout << "\t Znaleziono pasujacych produktow : " << found << "\n\n";
			for(i; i<this->record; i++){
        if(list[i].price >= price_a && list[i].price <= price_b){
          std::cout << "\t ID: " << list[i].no << ")\tNazwa: \t" << list[i].name;
          std::cout << "\n\t\tCena: \t" << list[i].price << " pln\n";
          std::cout << "\t\tOpis: \t" << list[i].description << "\n\n";
        }
      }
		}
		else{
      std::cout << "\t Nie znaleziono produktow pasujacych do frazy.\n\n";
		}
	}
	else{
   	std::cout << "\tBrak rekordow w bazie.\n\n";
	}
}

void Store::product_search_name(string name){
  
  // Laduj rekordy do bufora.  
	this->open_and_get();
	unsigned int found = 0, i = 0;
  int k;
	
	if(this->record){
		for(i; i<this->record; i++){
      k = list[i].name.find(name);
			if(k != string::npos){
				found++;
			}
		}
		if(found){
			i = 0;
			std::cout << "\t Znaleziono pasujacych produktow : " << found << "\n\n";
			for(i; i<this->record; i++){
        k = list[i].name.find(name);
        if(k != string::npos){
          std::cout << "\t ID: " << list[i].no << ")\tNazwa: \t" << list[i].name;
          std::cout << "\n\t\tCena: \t" << list[i].price << " pln\n";
          std::cout << "\t\tOpis: \t" << list[i].description << "\n\n";
        }
      }
		}
		else{
      std::cout << "\t Nie znaleziono produktow pasujacych do frazy.\n\n";
		}
	}
	else{
   	std::cout << "\tBrak rekordow w bazie.\n\n";
	}
}

void Store::product_sort(bool method){

  // Laduj rekordy do bufora.  
	this->open_and_get();
	unsigned int i = 0, j = 0, n = 0;
	
	if(this->record){
		if(method){
			list_sort_price = new Product[this->record];
      for(n; n<this->record; n++){
        list_sort_price[n].no = list[n].no;
        list_sort_price[n].name = list[n].name;
        list_sort_price[n].name = this->whitespace_remove(list_sort_price[n].name);                 
        list_sort_price[n].description = list[n].description;
        list_sort_price[n].description = this->whitespace_remove(list_sort_price[n].description);                         
        list_sort_price[n].price = list[n].price;
      }
			for(i; i<this->record; i++){
				for(j = 0; j<this->record-1; j++){
					if(list_sort_price[j].price >= list_sort_price[j+1].price ){
						list[j].name = list_sort_price[j+1].name;
						list[j].description = list_sort_price[j+1].description;
						list[j].price = list_sort_price[j+1].price;
						
						list_sort_price[j+1].name = list_sort_price[j].name;
						list_sort_price[j+1].description = list_sort_price[j].description;
						list_sort_price[j+1].price = list_sort_price[j].price;
						
						list_sort_price[j].name = list[j].name;
						list_sort_price[j].description = list[j].description;
						list_sort_price[j].price = list[j].price;
					}
				}
			}
			this->update_sort(true);
			std::cout << "\tBaza danych zostala posortowana wedlug klucza: cena.\n\n";
		}
		else{
 			list_sort_name = new Product[this->record];
			i = 0;
			j = 0;
			n = 0;
			for(n; n<this->record; n++){
        list_sort_name[n].no = list[n].no;
        list_sort_name[n].name = list[n].name;
        list_sort_name[n].name = this->whitespace_remove(list_sort_name[n].name);                                
        list_sort_name[n].description = list[n].description;
        list_sort_name[n].description = this->whitespace_remove(list_sort_name[n].description);        
        list_sort_name[n].price = list[n].price;
      }
			for(i; i<this->record; i++){
				for(j = 0; j<this->record-1; j++){
					if(list_sort_name[j].name >= list_sort_name[j+1].name ){
						list[j].name = list_sort_name[j+1].name;
						list[j].description = list_sort_name[j+1].description;
						list[j].price = list_sort_name[j+1].price;

						list_sort_name[j+1].name = list_sort_name[j].name;
						list_sort_name[j+1].description = list_sort_name[j].description;
						list_sort_name[j+1].price = list_sort_name[j].price;

						list_sort_name[j].name = list[j].name;
						list_sort_name[j].description = list[j].description;
						list_sort_name[j].price = list[j].price;
					}
				}
			}
			this->update_sort(false);
			std::cout << "\tBaza danych zostala posortowana wedlug klucza: nazwa.\n\n";
		}
	}
	else{
   	std::cout << "\tBrak rekordow w bazie.\n\n";
	}
}
