/*
  Typy zdefiniowane do opisu produktu.
*/

struct Product{
    unsigned int no;
    double price;
    string name;
    string description;
};
