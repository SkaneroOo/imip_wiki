#include "lagrange.hpp"

lagrange::lagrange()
{
	SSE=R_square=-1.0;
	Result;
}

void lagrange::load()
{
	fstream plik;
	plik.open("lagrange.txt", ios::in);
	if(plik.good())
	{
		int points_amount;
		double X,Y;
		plik >> points_amount;
		if (points_amount < 2)
		{
			cout << "Za malo punktow, minimum 2\n";
			plik.close();
			return;
		}
		
		for(int i = 0 ; i<points_amount ; i++)
		{
			plik >> X;
			plik >> Y;
			data.push_back(Punkt2D(X,Y));
		}
		sort(data.begin(), data.end());
		cout << "Twoje punkty to:\n";
		for (uint i = 0; i < data.size(); i++)
		{
			cout << 'P' << i + 1 << '(' << data[i].x << ',' << data[i].y << ')' << endl;
		}
		
		cout << "Przeprowadzic interpolacje na wszystkich punktach? [T]/[N]\n";
		char option;
		cin >> option;
		switch (option)
		{
			case 'T':
				full_interpolation();
				plik.close();
				break;
			case 'N':
				partial_interpolation(prefered_points());
				plik.close();
				break;
			default:
				plik.close();
				full_interpolation();
				break;
		}	
	}
	else
	{
		throw 1;
	}
}

vector<Punkt2D>& lagrange::prefered_points()
{
		if (data.size() != 2)
	{
		cout << "Wczytano " << data.size() << " punktow, ile chcesz wczytac? Minimum 2!\n";
		int ans;
		cin >> ans;
		while (ans < 2)
		{
			//system("CLS");
			cout << "Za malo punktow, minimum 2!\n";
			cin >> ans;
		}
		//system("CLS");
		cout << "Twoje punkty to:\n";
		for (uint i = 0; i < data.size(); i++)
		{
			cout << 'P' << i + 1 << '(' << data[i].x << ',' << data[i].y << ')' << endl;
		}
		cout << "Podaj indeksy punktów ktore chcesz uzyc\n";
		int index;
		vector<int> indices;
		for (int i = 0; i < ans; i++)
		{
			cin >> index;
			indices.push_back(index);
		}
			
		for (uint i = 0; i < indices.size(); i++)	data_part.push_back(data[indices[i]-1]);
		sort(data_part.begin(), data_part.end());
		//system("CLS");
		cout << "Twoje punkty to:\n";
		for (uint i = 0; i < data_part.size(); i++)
		{
			cout << 'P' << i + 1 << '(' << data_part[i].x << ',' << data_part[i].y << ')' << endl;
		}
		char anss;
		cout << "Czy chcesz dokonac interpolacji? [T]/[N]\n";
		cin >> anss;
		switch (anss)
		{
		case 'T':
			return data_part;;
			break;
		default:
			return data;
		}
	}
	else
	{
		return data;
	}
}

void lagrange::full_interpolation()
{
	sort(data.begin(),data.end());
	Polynomial W;
	for(uint i = 0 ; i<data.size() ; i++)
	{
		double mianownik = 1.0;
		Polynomial P(1.0);
		for(uint j = 0 ;j<data.size() ; j++)
		{
			if(i!=j)
			{
				mianownik *= data[i].x - data[j].x;
				P = P * Polynomial(1.0,-data[j].x);	
			}
		}
		double coeff = data[i].y / mianownik;
		P *= coeff;
		W += P;
	}
	Result = W;
	SSE_calculate(data);
	test(data);
}

void lagrange::partial_interpolation(vector<Punkt2D> &data)
{
	sort(data.begin(),data.end());
	Polynomial W;
	for(uint i = 0 ; i<data.size() ; i++)
	{
		double mianownik = 1.0;
		Polynomial P(1.0);
		for(uint j = 0 ;j<data.size() ; j++)
		{
			if(i!=j)
			{
				mianownik *= data[i].x - data[j].x;
				P = P * Polynomial(1.0,-data[j].x);	
			}
		}
		double coeff = data[i].y / mianownik;
		P *= coeff;
		W += P;
	}
	Result = W;
	SSE_calculate(this->data);
	//system("CLS");
	test(data);
}

void lagrange::SSE_calculate(vector<Punkt2D> &data)
{
	double sum = 0.0, avrg = 0.0, TSS = 0.0;
	
	for(uint i = 0 ; i<data.size() ; i++)
	{
		sum += (data[i].y-Result.operator()(data[i].x))*(data[i].y-Result.operator()(data[i].x));
		avrg += data[i].y;
	}
	avrg /= data.size();
	for(uint i = 0 ; i<data.size() ; i++)	TSS += (data[i].y - avrg)*(data[i].y - avrg);
	SSE = sum;
	R_square = 1.0 - SSE/TSS;
}

void lagrange::test(vector<Punkt2D> &data)
{
	cout<<"Wartosci wezlow i wartosci interpolowane:\n"<<Result<<endl;   
	for(uint i = 0 ; i<data.size(); i++)
	{
		cout<<"f("<<data[i].x<<") \tinput: "<<data[i].y<<"\t computed: "<<Result(data[i].x)<<endl;
	}
	cout<<endl;
}

void lagrange::review()
{
	if(SSE != -1.0 || R_square != -1.0)
	{
		cout<<"Interpolowany wielomian:\n"<<Result<<endl;
		cout<<"SSE = "<<SSE<<endl;
		cout<<"R square = "<<R_square<<endl;
	}
	else
	{
		cout<<"Nie dokonano interpolacji!\n";
	}
}
