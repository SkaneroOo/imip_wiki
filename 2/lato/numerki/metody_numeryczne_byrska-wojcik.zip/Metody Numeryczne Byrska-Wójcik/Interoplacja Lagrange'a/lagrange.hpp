#ifndef LAGRANGE_HPP
#define LAGRANGE_HPP

#include "Polynomial.hpp"
#include <fstream>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;
typedef unsigned int uint;

class lagrange
{
		vector<Punkt2D> data, data_part;
		void full_interpolation();
		void partial_interpolation(vector<Punkt2D>&);
		vector<Punkt2D>& prefered_points();
		void test(vector<Punkt2D>&);
		void SSE_calculate(vector<Punkt2D>&);
		double SSE,R_square;
		Polynomial Result;
	public:
		void load();
		void review();
		lagrange();
};

#endif
