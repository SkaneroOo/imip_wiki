#include "lagrange.hpp"

int main()
{
	
	lagrange L;
	try
	{
		L.load();
		L.review();
	}
	catch(int)
	{
		cerr<<"Nie ma takiego pliku\n";
	}
	//system("pause");
	return 0;
}
