#include "Approx.hpp"

using namespace std;

void Approx::load()
{
	fstream plik;
	plik.open("dane.txt", ios::in);
	if (plik.good())
	{
		int amount;
		double X, Y;
		plik >> amount;
		std::vector<Punkt2D> point;
		point.reserve(amount);
		for (int i = 0; i<amount; i++)
		{
			plik >> X;
			plik >> Y;
			point.push_back(Punkt2D(X, Y));
		}
		plik.close();
		//inter(point);
		inter2(point);
	}
	else
	{
		throw 1;
	}
}

void Approx::inter(std::vector<Punkt2D> &point)
{
	cout << "Wpisz stopien wielomianu:\n";
	int RANK;
	cin >> RANK;

	if (RANK != 0 && RANK != 1 && RANK != 2)
	{
		RANK = 2;
	}
	// Tworzenie bazy
	std::vector<Polynomial> base;
	for (int i = 0; i < 2 * RANK + 1; i++)
		base.push_back(Polynomial(1.0, i));
	// Tworzenie sum do macierzy
	std::vector<double> sum;
	for (unsigned int i = 0; i < base.size(); i++)
	{
		double partial = 0.0;
		for (unsigned int j = 0; j < point.size(); j++)
		{
			partial += base[i](point[j].x);
		}
		sum.push_back(partial);
	}
	// Tworzenie macierzy
	int SIZE = RANK+1;

	std::vector<std::vector<double> > matrix;
	for (int i = 0; i < SIZE; i++)	matrix.push_back(std::vector<double>());
	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
			matrix[i].push_back(double());
	}
	//Wype�nianie macierzy
	int add = RANK + 1;
	for (unsigned int i = 0; i < matrix[0].size(); i++)
		matrix[0][i] = sum[i];
	for (unsigned int i = 1; i < matrix.size(); i++)
	{
		for (int j = 0; j < matrix[i].size()-1; j++)
			matrix[i][j] = matrix[i - 1][j + 1];
		matrix[i][matrix[i].size()-1] = sum[add++];
	}
	// wektor wynikow
	std::vector<double> cramer(SIZE);
	for (unsigned int i = 0; i < cramer.size(); i++)
	{
		double sum = 0.0;
		for (unsigned int j = 0; j < point.size(); j++)
		{
			sum += point[j].y*base[i](point[j].x);
		}
		cramer[i] = sum;
	}
	double mainDeterminant;	
	std::vector<double> determinant(cramer.size());
	if (matrix.size() == 1)
	{
		
		determinant[0] = cramer[0]/matrix[0][0];
			
	}
	if (matrix.size() == 2)
	{
		/*mainDeterminant = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];*/
		mainDeterminant = det(matrix);
		for (unsigned int i = 0; i < cramer.size(); i++)
		{
			for (unsigned int j = 0; j < cramer.size(); j++)
			{
				swap(cramer[j], matrix[j][i]);
			}
			determinant[i] = det(matrix);
			for (unsigned int j = 0; j < cramer.size(); j++)
			{
				swap(cramer[j], matrix[j][i]);
			}
		}
		for (unsigned int i = 0; i < cramer.size(); i++)
			determinant[i] /= mainDeterminant;
	}
	if(matrix.size()==3)
	{
		mainDeterminant = det(matrix);
		for (unsigned int i = 0; i < cramer.size(); i++)
		{
			for (unsigned int j = 0; j < cramer.size(); j++)
			{
				swap(cramer[j], matrix[j][i]);
			}
			determinant[i] = det(matrix);
			for (unsigned int j = 0; j < cramer.size(); j++)
			{
				swap(cramer[j], matrix[j][i]);
			}
		}
		for (unsigned int i = 0; i < cramer.size(); i++)
			determinant[i] /= mainDeterminant;
	}
	for (unsigned int i = 0; i < cramer.size(); i++)
		Result += base[i] * determinant[i];
	SSE_calculate(point);
}

void Approx::inter2(std::vector<Punkt2D> &point)
{
	cout << "Wpisz stopien wielomianu:\n";
	int RANK;
	cin >> RANK;
	if (RANK < 0)	RANK = 2;

	// Tworzenie bazy
	std::vector<Polynomial> base; 
	base.reserve(2 * RANK);
	for (int i = 0; i < 2 * RANK + 1; i++)
		base.push_back(Polynomial(1.0, i));

	// Tworzenie sum do macierzy
	std::vector<double> sum;
	sum.reserve(base.size());
	for (unsigned int i = 0; i < base.size(); i++)
	{
		double partial = 0.0;
		for (unsigned int j = 0; j < point.size(); j++)
		{
			partial += base[i](point[j].x);
		}
		sum.push_back(partial);
	}
	// Tworzenie macierzy
	int SIZE = RANK + 1;

	std::vector<std::vector<double> > matrix(SIZE, std::vector<double>(SIZE));

	//Wype�nianie macierzy
	int add = RANK + 1;
	for (unsigned int i = 0; i < matrix[0].size(); i++)
		matrix[0][i] = sum[i];
	for (unsigned int i = 1; i < matrix.size(); i++)
	{
		for (int j = 0; j < matrix[i].size() - 1; j++)
			matrix[i][j] = matrix[i - 1][j + 1];
		matrix[i][matrix[i].size() - 1] = sum[add++];
	}
	// wektor wynikow
	std::vector<double> vector(SIZE);
	for (unsigned int i = 0; i < vector.size(); i++)
	{
		double sum = 0.0;
		for (unsigned int j = 0; j < point.size(); j++)
		{
			sum += point[j].y*base[i](point[j].x);
		}
		vector[i] = sum;
	}

	// Tworzenie macierzy rozszerzonej poprzez dodanie do niej wektora bn
	for (unsigned int i = 0; i < matrix.size(); i++) {
		matrix[i].push_back(vector[i]);
	}
	//Zerowanie macierzy aka Gauss
	for (int k = 0; k < matrix.size() + 1; k++) {
		for (int i = 1+k; i < matrix.size(); i++)
		{
			double coeff = matrix[i][k] / matrix[k][k];
			for (int j = k; j < matrix[i].size(); j++)
			{
				matrix[i][j] -= coeff*matrix[k][j];
			}
		} 
	}

	// Redukowanie macierzy rozszerzonej o wektor bn
	int at = vector.size();
	for (unsigned int i = 0; i < matrix.size(); i++) {
		vector[i] = matrix[i][at];
		matrix[i].pop_back();
	}

	// Eliminacja Gaussa
	std::vector<double> X = std::vector<double>(vector.size());
	int n = vector.size() - 1;
	if (n == vector.size() - 1)
		X[n] = vector[n] / matrix[n][n];
	if (vector.size() > 1) {
		int k = 2;
		for (int i = vector.size() - 2; i >= 0; i--, k++) {

			double eq = vector[i];
			for (int j = vector.size() - 1; j > vector.size()-k; j--) {
				eq -= X[j] * matrix[i][j];
			}
			X[i] = eq / matrix[i][i];
		}
	}
	//Tworzenie wielomianu wynikowego na podstawie obliczonych wsp�lczynnik�w
	Polynomial W(X[0]);
	if (X.size() > 1) {
		for (int i = 1; i < X.size(); i++)
			W.raiseDeg(X[i]);
	}
	Result = W;
	SSE_calculate(point);
}


Approx::Approx()
{
	SSE = -1.0;
	R_square = -1.0;
}

double Approx::det(std::vector<std::vector<double> >&matrix)
{
	if (matrix.size() == 2)
	{
		return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
	}
	if (matrix.size() == 3)
	{
		double detSum = 0.0;
		for (unsigned int i = 0; i < 3; i++)
		{
			double detDiagonal = 1.0;
			for (unsigned int j = 0; j < 3; j++)
				detDiagonal *= matrix[j][(i + j) % 3];
			detSum += detDiagonal;
		}
		for (int i = 0; i<3; i++)
		{
			double detDiagonal = 1.0;
			for (int j = 0; j < 3; j++)
				detDiagonal *= matrix[2 - j][(i + j)%3];
			detSum -= detDiagonal;
		}
		return detSum;
	}
	return 0.0;
}

void Approx::SSE_calculate(vector<Punkt2D> &data)
{
	double sum = 0.0, avrg = 0.0, TSS = 0.0;

	for (unsigned int i = 0; i<data.size(); i++)
	{
		sum += (data[i].y - Result.operator()(data[i].x))*(data[i].y - Result.operator()(data[i].x));
		avrg += data[i].y;
	}
	avrg /= data.size();
	for (unsigned int i = 0; i<data.size(); i++)	TSS += (data[i].y - avrg)*(data[i].y - avrg);
	SSE = sum;
	R_square = 1.0 - SSE / TSS;
}

void Approx::decomposeLU(std::vector<std::vector<double> > &A)
{
	std::vector<std::vector<double> > L(A.size()), U(A.size());
	for (unsigned int i = 0; i < A.size(); i++) {
		for (unsigned int j = 0; j < A.size() - i; j++)
			U[i].push_back(0.0);
		for (unsigned int j = 0; j < i + 1; j++)
			L[i].push_back(0.0);
	}
	for (unsigned int i = 0; i < L.size(); i++)
		L[i][i] = 1.0;
	for (unsigned int i = 0; i < A.size(); i++)
		U[0][i] = A[0][i];
	for (unsigned int k = 0; k < A.size(); k++) {
		for (unsigned int i = 1 + k; i < A.size(); i++)
		{
			double coeff = A[i][k] / A[k][k];
			L[i][k] = coeff;
			for (unsigned int j = k; j < A[i].size(); j++)
			{
				A[i][j] -= coeff*A[k][j];
				if (i <= j)
					U[i][j - i] = A[i][j];
			}
		}
	}
}

void Approx::print()
{
	if (SSE != -1.0 || R_square != -1.0)
	{
		cout << "Aproksymowany wielomian:\n" << Result << endl;
		cout << "SSE = " << SSE << endl;
		cout << "R square = " << R_square << endl;
	}
	else
	{
		cout << "Nie dokonano aproksymacji!\n";
	}
}
