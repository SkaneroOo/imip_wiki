#include <iostream>
#include "Approx.hpp"
using namespace std;

int main()
{
	Approx A;
	try{
		A.load();
		A.print();
	}
	catch (int) {
		cerr << "Blad wczytywania\n";
}
	//system("pause");
	return 0;

}
