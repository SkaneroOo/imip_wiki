#ifndef APPROX_HPP
#define APPROX_HPP
#include "Polynomial.hpp"
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>

class Approx
{
	double SSE,R_square;
	double det(std::vector<std::vector<double> >&);
	void SSE_calculate(std::vector<Punkt2D>&);
	
public:
	void decomposeLU(std::vector<std::vector<double> >&);
	Polynomial Result;
	void load();
	void inter(std::vector<Punkt2D>&);
	void inter2(std::vector<Punkt2D>&);
	void print();
	Approx();
};
#endif
