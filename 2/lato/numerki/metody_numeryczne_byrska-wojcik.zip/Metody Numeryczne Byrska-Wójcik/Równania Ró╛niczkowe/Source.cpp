#include <iostream>
using namespace std;

double f(double, double);
double fi_rk2(double, double, double);
double fi_rk4(double, double, double);

int main()
{
	double a, b, h;
	const int N = 10;
	cin >> a >> b;
	h = (b - a) / static_cast<double>(N);
	/*
	//Metoda Eulera
	double y = 0.1, x = a;
	cout << "\nEuler:\nx = " << x << " y = " << y << endl;
	for (int i = 0; i < N; i++) {
		y += h*f(x, y);
		x += h;
		cout << "x = " << x << " y = " << y << endl;
	}
	//Metoda Heuna(modyfikowana Eulera)
	y = 0.1, x = a;
	cout << "\nHeun:\nx = " << x << " y = " << y << endl;
	for (int i = 0; i < N; i++) {
		y += 0.5*h*(f(x, y)+f(x+h,y+h*f(x,y)));
		x += h;
		cout << "x = " << x << " y = " << y << endl;
	}
	
	// Zmodyfikowana Metoda Eulera
	y = 0.1, x = a;
	cout << "\nMod. Euler:\nx = " << x << " y = " << y << endl;
	for (int i = 0; i < N; i++) {
		y += h*f(x + 0.5*h, y + 0.5*h*f(x, y));
		x += h;
		cout << "x = " << x << " y = " << y << endl;
	}
	*/
	double(*fi)(double, double, double) = fi_rk2;
	double y = 1.0, x = a;
	cout << "\nMetoda Rungego-Kutty (RK2):\nx = " << x << " y = " << y << endl;
	for (int i = 0; i < N; ++i) {
		y += h*fi(x, y, h);
		x += h;
		cout << "x = " << x << " y = " << y << endl;
	}

	y = 1.0, x = a;
	fi = fi_rk4;
	cout << "\nMetoda Rungego-Kutty (RK4):\nx = " << x << " y = " << y << endl;
	for (int i = 0; i < N; ++i) {
		y += h*fi(x, y, h);
		x += h;
		cout << "x = " << x << " y = " << y << endl;
	}
	system("pause");
	return 0;
}

//inline double f(double x, double y) {
//	return (x*x + y);
//}

inline double f(double x, double y) {
	return (y - x*x);
}

double fi_rk2(double x, double y, double h) {
	double k[2];
	k[0] = f(x, y),
	k[1] = f(x + h, y + h*k[0]);
	return 0.5*(k[0] + k[1]);
}

double fi_rk4(double x, double y, double h) {
	double k[4];
		k[0] = f(x, y),
		k[1] = f(x + 0.5*h, y + 0.5*h*k[0]),
		k[2] = f(x + 0.5*h, y + 0.5*h*k[1]),
		k[3] = f(x + h, y + h*k[2]);
		return (k[0] + 2.0*k[1] + 2.0*k[2] + k[3]) / 6.0;
}
