#ifndef HERMITE_HPP
#define HERMITE_HPP

#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include "Derivative.hpp"
#include "Polynomial.hpp"
using namespace std;


class hermite
{
		vector<double> x,bk;
		vector<Derivative> node;
		Polynomial Result;
		vector<vector<double> > y;
		int nodes_amount;
		int factorial(int);
		void fillDiagonal(); 
	public:
		hermite();
		void load();			//load data from hermite.txt
		void review();			//prints the result-polynomial
		void printDiagonal();	//prints triangle matrix of values 
		void printBk();			//prints Newton's coefficients
};
#endif
