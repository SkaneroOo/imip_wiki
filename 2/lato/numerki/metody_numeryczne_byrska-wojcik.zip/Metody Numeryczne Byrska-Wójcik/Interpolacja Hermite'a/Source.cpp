#include "hermite.hpp"

int main()
{
	hermite H;
	try{
		H.load();
	}
	catch (int)
	{
		cerr<<"Blad pliku\n";
	}
	cout<<endl;
	H.printDiagonal();
	cout<<endl;
	H.printBk();
	H.review();
	system("pause");
	return 0;
}
