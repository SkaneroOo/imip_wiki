#include "Derivative.hpp"

Derivative::Derivative(double arg)	:	x(arg)
{}

void Derivative::push_back(double C)
{y.push_back(C);}

uint Derivative::getRank()
{return y.size();}

double Derivative::getDerivative(uint I)
{	return y[I];}

ostream& operator<<(ostream &S, Derivative &D)
{
	for(uint  i = 0 ;i<D.y.size() ; i++)
	{
		S<<"f";
		for(uint j = 0 ; j<i ; j++)	S<<"'";
		S << "(" << D.x << ")=" << D.getDerivative(i) << "\t";
	}
	return S;
}

bool Derivative::operator<(Derivative &D)
{
	return (x<D.x);
}
