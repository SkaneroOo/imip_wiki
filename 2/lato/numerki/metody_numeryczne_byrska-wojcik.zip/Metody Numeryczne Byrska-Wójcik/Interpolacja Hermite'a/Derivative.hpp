#ifndef DERIVATIVE_HPP
#define DERIVATIVE_HPP
#include <vector>
#include <iostream>

using namespace std;
typedef unsigned int uint;
class Derivative
{
	
	vector<double> y;
	public:
		double x;
		void push_back(double);
		uint getRank();
		double getDerivative(uint);
		Derivative(double = 0);
		friend ostream& operator<<(ostream&, Derivative&);
		bool operator<(Derivative&);
};

#endif
