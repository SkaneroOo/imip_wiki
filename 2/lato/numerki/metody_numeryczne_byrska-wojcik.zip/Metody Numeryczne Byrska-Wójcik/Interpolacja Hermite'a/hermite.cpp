#include "hermite.hpp"

hermite::hermite()
{
	nodes_amount = 0;
}

void hermite::load()
{
	fstream plik;
	plik.open("hermite.txt", ios::in);
	if(plik.good())
	{
		
		/*Wczytywanie punktow i wartosci w jego pochodnych do wektora*/
		int derivatives_amount, y_amount;
		double X,Y;
		plik >> derivatives_amount;
		
		for(int i = 0 ; i<derivatives_amount ; i++)
		{
			plik >> X;	
			node.push_back(Derivative(X));
			plik >>  y_amount;
			for(int j = 0 ; j<y_amount ; j++)
			{
				x.push_back(X);
				plik >> Y;
				node[i].push_back(Y);
			}
		}
		plik.close();
		
		/* Przepisywanie wartosci do macierzy trojkatnej*/
		nodes_amount = x.size();
		if(nodes_amount>1)
		{
			sort(x.begin(),x.end());
			sort(node.begin(),node.end());

			for(unsigned int i = 0 ; i < node.size() ; i++)	cout<<node[i]<<endl;
			for(uint i = 0 ; i < nodes_amount ; i++)	y.push_back(vector<double>());

			int pos=0,iterator=0;
			while(pos<nodes_amount)
			{
				int col = 1;
				for(int i = pos ; i<pos+node[iterator].getRank() ; i++)
				{
					for(int j = 0 ; j<col ; j++)
						y[i].push_back(node[iterator].getDerivative(j)/factorial(j));
					col++;
				}
				pos += node[iterator].getRank();
				iterator++;
			}
			fillDiagonal();
		}
		else
		{
			cerr<<"Za mala ilosc punktow\n";
		}
	}
	else
	{
		throw 1;
	}
}

void hermite::fillDiagonal()
{
	for(int i = 0 ; i < nodes_amount ; i++)
	{
			if(y[i].size()<i+1)
			{
				for (unsigned int j = y[i].size(); j < i + 1; j++)
					y[i].push_back((y[i][j-1] - y[i-1][j-1])/(x[i] - x[i-j]));
			}

	}
	

	for(int i = 0 ; i<nodes_amount ; i++)	bk.push_back(y[i][i]);
	
	Result = Polynomial(bk[0]);
	for(int i = 1 ; i<nodes_amount ; i++)
	{
		Polynomial P(1.0);
		for(int  j = 0 ; j<i ; j++)	P = P * Polynomial(1.0,-x[j]);
		P *= bk[i];
		Result += P;
	}
}

void hermite::printDiagonal()
{
	for(unsigned int i = 0 ; i < x.size() ; i++)
	{
		cout<<x[i]<<"\t";
		for(unsigned j = 0 ; j<y[i].size() ; j++)
		{
			cout<<y[i][j]<<"\t";
		}
		cout<<endl;
	}
}

void hermite::printBk()
{
	if(bk.size())
	{
		cout<<"Bk:\t";
		for(int i = 0 ; i<bk.size() ; i++)	cout<<bk[i]<<"\t";
		cout<<endl;
	}
	else
	{
		cerr<<"Nie obliczono jeszcze wspolczynnikow Newtona!\n";
	}
}

void hermite::review()
{
	cout<<"Interpolowany wielomian:\n"<<Result<<endl;
}

 int hermite::factorial(int n)
{
	if(n==0) return 1;
	else return n*factorial(n-1);
}
